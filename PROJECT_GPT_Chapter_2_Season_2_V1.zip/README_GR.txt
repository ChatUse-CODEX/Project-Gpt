PROJECT GPT — CHAPTER 2 SEASON 2 · V1
===================================

Αυτό είναι ένα ΠΑΙΞΙΜΟ 3D Battle Royale prototype για tablet και υπολογιστή.
Δεν είναι το επίσημο Fortnite και δεν περιέχει αυθεντικά assets/skins της Epic Games.

ΠΕΡΙΛΑΜΒΑΝΕΙ:
- 3D νησί με 10 πρωτότυπα POIs, κτίρια, δρόμους, δέντρα, χάρτη.
- Third-person κάμερα, κίνηση, άλμα, τρέξιμο, σκύψιμο, στόχευση.
- 4 τύπους όπλων (AR, Shotgun, SMG, Sniper), πυροβολισμούς και reload.
- 12 bots με AI που κινούνται, πολεμούν μεταξύ τους και σε κυνηγούν.
- Supply crates για ammo, health και shield.
- Storm που μικραίνει, eliminations, Victory Royale και statistics.
- Ρυθμίσεις ποιότητας, ευαισθησίας, δυσκολίας, auto-fire και FPS.
- Κουμπιά αφής για Android tablet / πλήκτρα για PC, χωρίς διαφημίσεις.
- Local αποθήκευση νικών και settings.

ΔΕΝ ΠΕΡΙΛΑΜΒΑΝΕΙ ΣΕ ΑΥΤΗ ΤΗΝ ΕΚΔΟΣΗ:
- Online παιχνίδι με πραγματικούς παίκτες (χρειάζεται multiplayer server).
- Creative, κτίσιμο/editing, Solo/Duos/Squads online.
- Locker, 300 skins/pickaxes/gliders/emotes, Item Shop, Admin, Battle Pass.
- Τα 18 αυθεντικά Fortnite POIs: υπάρχουν 10 ΠΡΩΤΟΤΥΠΕΣ περιοχές.

ΕΓΚΑΤΑΣΤΑΣΗ ΣΤΟ GITHUB PAGES:
1. Πήγαινε στο GitHub repository σου (μπορείς να φτιάξεις νέο: project-gpt).
2. Ανέβασε ΟΛΑ τα αρχεία του φακέλου αποσυμπιεσμένα: index.html, style.css,
   game.js, manifest.webmanifest, icon-192.png, icon-512.png. Μην ανεβάσεις μόνο το ZIP.
3. Πάτα Commit changes.
4. Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. Περίμενε λίγα λεπτά και άνοιξε το link:
   https://TO-USERNAME-SOU.github.io/project-gpt/
6. Παίξε από Chrome σε οριζόντιο προσανατολισμό tablet.

ΣΗΜΑΝΤΙΚΟ: Το game.js φορτώνει το Three.js από το δημόσιο CDN jsdelivr.
Χρειάζεσαι σύνδεση στο Internet για την πρώτη φόρτωση.
Αν δεις άδεια οθόνη, δοκίμασε ανανέωση ή έλεγξε τη σύνδεση.

ΧΕΙΡΙΣΜΟΣ TABLET:
- Αριστερό joystick = κίνηση
- Σύρε δεξιά στην οθόνη = γύρνα την κάμερα / σημάδεψε
- FIRE = συνεχόμενος πυροβολισμός
- JUMP, RELOAD, WEAPON, CROUCH, RUN = αντίστοιχες ενέργειες

ΧΕΙΡΙΣΜΟΣ ΥΠΟΛΟΓΙΣΤΗ:
- WASD = κίνηση, mouse = κάμερα, click = πυροβολισμός
- Space = άλμα, Shift = τρέξιμο, Ctrl = crouch
- 1/2/3/4 = όπλο, R = reload, Esc = pause

Δημιουργήθηκε ως πρωτότυπο ανεξάρτητο fan project, χωρίς διαφημίσεις.

ΓΙΑ ΣΥΝΤΟΜΕΥΣΗ ΣΤΟ TABLET: Άνοιξε το GitHub Pages link στον Chrome και
πάτα τις 3 τελείες > Προσθήκη στην αρχική οθόνη (ή Εγκατάσταση εφαρμογής).
